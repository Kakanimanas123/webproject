import React, { useState } from 'react';
import { useAppContext } from '../../contexts/AppContext';
import SummaryCard from './SummaryCard';
import Card, { CardHeader, CardBody } from '../ui/Card';
import Button from '../ui/Button';
import { Users, PackageCheck, BarChart3, Award, Calendar, Check, Clock, AlertCircle } from 'lucide-react';
import { formatDate, isDatePast, getUrgencyClass, daysUntil } from '../../utils/helpers';

const Dashboard: React.FC = () => {
  const { leads, orders, reminders, getDashboardSummary } = useAppContext();
  const [timeframe, setTimeframe] = useState<'today' | 'week' | 'month'>('week');
  
  const dashboardData = getDashboardSummary();

  // Calculate conversion rate
  const conversionRate = dashboardData.totalLeads > 0 
    ? ((dashboardData.wonLeads / dashboardData.totalLeads) * 100).toFixed(1) 
    : '0';

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant={timeframe === 'today' ? 'primary' : 'outline'}
            onClick={() => setTimeframe('today')}
          >
            Today
          </Button>
          <Button
            size="sm"
            variant={timeframe === 'week' ? 'primary' : 'outline'}
            onClick={() => setTimeframe('week')}
          >
            This Week
          </Button>
          <Button
            size="sm"
            variant={timeframe === 'month' ? 'primary' : 'outline'}
            onClick={() => setTimeframe('month')}
          >
            This Month
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <SummaryCard
          title="Total Leads"
          value={dashboardData.totalLeads}
          icon={<Users size={24} className="text-blue-600" />}
        />
        <SummaryCard
          title="Open Leads"
          value={dashboardData.openLeads}
          icon={<Users size={24} className="text-indigo-600" />}
        />
        <SummaryCard
          title="Conversion Rate"
          value={`${conversionRate}%`}
          icon={<Award size={24} className="text-green-600" />}
          trend={
            dashboardData.totalLeads > 5
              ? { value: 5, label: 'vs last period', positive: true }
              : undefined
          }
        />
        <SummaryCard
          title="Active Orders"
          value={dashboardData.ordersReceived + dashboardData.ordersInDevelopment + dashboardData.ordersReadyToDispatch}
          icon={<PackageCheck size={24} className="text-purple-600" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Lead Pipeline */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <h2 className="text-lg font-medium text-gray-900">Lead Pipeline</h2>
          </CardHeader>
          <CardBody className="pb-6">
            <div className="relative pt-4">
              <div className="flex mb-2">
                <div className="h-2 w-full bg-blue-100 rounded-l-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600"
                    style={{
                      width: `${dashboardData.totalLeads ? (dashboardData.openLeads / dashboardData.totalLeads) * 100 : 0}%`,
                    }}
                  ></div>
                </div>
                <div className="h-2 w-full bg-green-100 rounded-r-full overflow-hidden">
                  <div
                    className="h-full bg-green-600"
                    style={{
                      width: `${dashboardData.totalLeads ? (dashboardData.wonLeads / dashboardData.totalLeads) * 100 : 0}%`,
                    }}
                  ></div>
                </div>
              </div>
              <div className="flex justify-between text-sm">
                <div>
                  <span className="text-blue-600 font-medium">{dashboardData.openLeads}</span> Open
                </div>
                <div>
                  <span className="text-green-600 font-medium">{dashboardData.wonLeads}</span> Won
                </div>
                <div>
                  <span className="text-red-600 font-medium">{dashboardData.totalLeads - dashboardData.openLeads - dashboardData.wonLeads}</span> Lost
                </div>
              </div>
            </div>

            <div className="mt-8 space-y-4">
              <h3 className="text-sm font-medium text-gray-500">Order Status</h3>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">Order Received</span>
                  <span className="text-sm font-medium text-gray-900">{dashboardData.ordersReceived}</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-600 h-full"
                    style={{
                      width: `${
                        orders.length
                          ? (dashboardData.ordersReceived / orders.length) * 100
                          : 0
                      }%`,
                    }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">In Development</span>
                  <span className="text-sm font-medium text-gray-900">{dashboardData.ordersInDevelopment}</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-yellow-500 h-full"
                    style={{
                      width: `${
                        orders.length
                          ? (dashboardData.ordersInDevelopment / orders.length) * 100
                          : 0
                      }%`,
                    }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">Ready to Dispatch</span>
                  <span className="text-sm font-medium text-gray-900">{dashboardData.ordersReadyToDispatch}</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full"
                    style={{
                      width: `${
                        orders.length
                          ? (dashboardData.ordersReadyToDispatch / orders.length) * 100
                          : 0
                      }%`,
                    }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">Dispatched</span>
                  <span className="text-sm font-medium text-gray-900">{dashboardData.ordersDispatched}</span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-green-600 h-full"
                    style={{
                      width: `${
                        orders.length
                          ? (dashboardData.ordersDispatched / orders.length) * 100
                          : 0
                      }%`,
                    }}
                  ></div>
                </div>
              </div>
            </div>
          </CardBody>
        </Card>

        {/* Upcoming Follow-ups */}
        <Card>
          <CardHeader className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-gray-900">Upcoming Follow-ups</h2>
            <Calendar size={18} className="text-blue-600" />
          </CardHeader>
          <CardBody className="pb-6">
            {dashboardData.upcomingFollowUps.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>No upcoming follow-ups</p>
              </div>
            ) : (
              <ul className="divide-y divide-gray-200">
                {dashboardData.upcomingFollowUps.map((reminder) => {
                  const isPast = isDatePast(reminder.date);
                  const days = daysUntil(reminder.date);

                  return (
                    <li key={reminder.id} className="py-3">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 mr-3">
                          {reminder.completed ? (
                            <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                              <Check size={14} className="text-green-600" />
                            </div>
                          ) : isPast ? (
                            <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center">
                              <AlertCircle size={14} className="text-red-600" />
                            </div>
                          ) : (
                            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                              <Clock size={14} className="text-blue-600" />
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900 line-clamp-1">
                            {reminder.title}
                          </p>
                          <div className="flex items-center text-xs">
                            <span className={`${getUrgencyClass(days)}`}>
                              {formatDate(reminder.date)}
                            </span>
                            <span className="mx-1">•</span>
                            <span className="text-gray-500">
                              {isPast
                                ? 'Overdue'
                                : days === 0
                                ? 'Today'
                                : `In ${days} days`}
                            </span>
                          </div>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;