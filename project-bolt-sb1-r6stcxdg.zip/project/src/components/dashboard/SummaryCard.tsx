import React from 'react';
import Card from '../ui/Card';

interface SummaryCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  trend?: {
    value: number;
    label: string;
    positive?: boolean;
  };
  className?: string;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, value, icon, trend, className = '' }) => {
  return (
    <Card className={`transition-transform duration-300 hover:shadow-md ${className}`}>
      <div className="p-5">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="mt-1 text-2xl font-semibold text-gray-900">{value}</p>
          </div>
          <div className="bg-blue-50 p-2 rounded-md">
            {icon}
          </div>
        </div>
        {trend && (
          <div className="mt-3">
            <span className={`inline-flex items-center text-sm ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
              {trend.positive ? '↑' : '↓'} {trend.value}%
              <span className="ml-1 text-gray-500">{trend.label}</span>
            </span>
          </div>
        )}
      </div>
    </Card>
  );
};

export default SummaryCard;